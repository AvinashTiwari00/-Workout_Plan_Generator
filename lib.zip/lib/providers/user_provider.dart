import 'package:flutter/foundation.dart';
import 'package:college_project/models/user_models.dart';

class UserProvider extends ChangeNotifier {
  User? _user;
  UserAccount? _account;
  UserProfile? _profile;

  User? get user => _user;
  UserAccount? get account => _account;
  UserProfile? get profile => _profile;

  void setSession({
    required User user,
    required UserAccount account,
    required UserProfile profile,
  }) {
    _user = user;
    _account = account;
    _profile = profile;
    notifyListeners();
  }

  void setAccount(UserAccount account, {UserProfile? profile}) {
    _account = account;
    _profile = profile;
    notifyListeners();
  }

  void setUser(User user, {UserProfile? profile}) {
    _user = user;
    _profile = profile;
    notifyListeners();
  }

  void clear() {
    _user = null;
    _account = null;
    _profile = null;
    notifyListeners();
  }
}
