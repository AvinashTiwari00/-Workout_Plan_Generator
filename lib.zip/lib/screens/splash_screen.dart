import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:college_project/providers/user_provider.dart';
import 'package:college_project/repositories/user_repository.dart';
import 'package:college_project/screens/dashboard_screen.dart';
import 'package:college_project/screens/user_input_screen.dart';
import 'package:college_project/screens/welcome_screen.dart';
import 'package:college_project/utils/session_store.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final _session = SessionStore();
  final _users = UserRepository();
  bool _checked = false;

  @override
  void initState() {
    super.initState();
    _startCheck();
  }

  Future<void> _startCheck() async {
    if (_checked) return;
    _checked = true;

    // Small delay so navigation happens after first frame
    await Future.delayed(const Duration(seconds: 1));

    try {
      final userId = await _session.readUserId();
      if (!mounted) return;

      if (userId == null) {
        _openWelcome();
        return;
      }

      final account = await _users.getAccount(userId);
      if (!mounted) return;
      if (account == null) {
        await _session.clear();
        if (!mounted) return;
        _openWelcome();
        return;
      }

      final profile = await _users.getProfile(userId);
      final user = await _users.loadDashboardUser(userId);
      if (!mounted) return;

      if (user == null || profile == null) {
        context.read<UserProvider>().setAccount(account, profile: profile);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const UserInputScreen()),
        );
        return;
      }

      context.read<UserProvider>().setSession(
        user: user,
        account: account,
        profile: profile,
      );
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => DashboardScreen(user: user)),
      );
    } catch (e) {
      debugPrint('Splash auth error: $e');
      if (!mounted) return;
      _openWelcome();
    }
  }

  void _openWelcome() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const WelcomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.fitness_center, size: 72, color: Colors.blue),
            SizedBox(height: 16),
            Text(
              "Workout Plan Generator",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 24),
            CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}
