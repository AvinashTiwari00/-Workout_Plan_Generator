import 'package:college_project/models/user_models.dart';
import 'package:college_project/models/workout_plan.dart';
import 'package:college_project/providers/user_provider.dart';
import 'package:college_project/repositories/user_repository.dart';
import 'package:college_project/repositories/weight_repository.dart';
import 'package:college_project/screens/dashboard_screen.dart';
import 'package:college_project/utils/session_store.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _users = UserRepository();
  final _weights = WeightRepository();
  final _session = SessionStore();

  final _nameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _ageCtrl = TextEditingController();
  final _heightCtrl = TextEditingController();
  final _weightCtrl = TextEditingController();

  UserGoal? _goal;
  ExperienceLevel? _experience;
  WorkoutLocation? _location;

  bool _isLoading = false;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _passwordCtrl.dispose();
    _ageCtrl.dispose();
    _heightCtrl.dispose();
    _weightCtrl.dispose();
    super.dispose();
  }

  Future<void> _signup() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    final result = await _users.createAccount(
      username: _nameCtrl.text,
      password: _passwordCtrl.text,
      age: int.tryParse(_ageCtrl.text.trim()),
      heightCm: double.tryParse(_heightCtrl.text.trim()),
      goal: _goal,
      experienceLevel: _experience,
      workoutLocation: _location,
    );

    if (!mounted) return;

    if (!result.isSuccess) {
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.error ?? 'Could not create account')),
      );
      return;
    }

    final account = result.account!;
    final profile = result.profile!;
    final weight = double.tryParse(_weightCtrl.text.trim());
    if (weight != null && weight > 0) {
      await _weights.addLog(userId: account.id, weightKg: weight);
    }
    await _session.saveUserId(account.id);

    final user = await _users.loadDashboardUser(account.id);
    if (!mounted) return;
    setState(() => _isLoading = false);

    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not load your profile')),
      );
      return;
    }

    context.read<UserProvider>().setSession(
      user: user,
      account: account,
      profile: profile,
    );

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => DashboardScreen(user: user)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sign Up'), centerTitle: true),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _nameCtrl,
                decoration: const InputDecoration(labelText: 'Name'),
                validator: (v) =>
                    v == null || v.trim().isEmpty ? 'Enter your name' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _passwordCtrl,
                decoration: const InputDecoration(labelText: 'Password'),
                obscureText: true,
                validator: (v) =>
                    v == null || v.trim().isEmpty ? 'Enter a password' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _ageCtrl,
                decoration: const InputDecoration(labelText: 'Age'),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _heightCtrl,
                decoration: const InputDecoration(labelText: 'Height'),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _weightCtrl,
                decoration: const InputDecoration(labelText: 'Weight'),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 12),
              _dropdown<UserGoal>(
                label: 'Goal',
                value: _goal,
                items: UserGoal.values,
                labelOf: (goal) => goal.label,
                onChanged: (value) => setState(() => _goal = value),
                errorText: 'Select a goal',
              ),
              const SizedBox(height: 12),
              _dropdown<ExperienceLevel>(
                label: 'Experience Level',
                value: _experience,
                items: ExperienceLevel.values,
                labelOf: (level) => level.label,
                onChanged: (value) => setState(() => _experience = value),
                errorText: 'Select an experience level',
              ),
              const SizedBox(height: 12),
              _dropdown<WorkoutLocation>(
                label: 'Workout Location',
                value: _location,
                items: WorkoutLocation.values,
                labelOf: (location) => location.label,
                onChanged: (value) => setState(() => _location = value),
                errorText: 'Select a workout location',
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _isLoading ? null : _signup,
                child: _isLoading
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text('Sign Up'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _dropdown<T>({
    required String label,
    required T? value,
    required List<T> items,
    required String Function(T) labelOf,
    required ValueChanged<T?> onChanged,
    required String errorText,
  }) {
    return DropdownButtonFormField<T>(
      initialValue: value,
      isExpanded: true,
      decoration: InputDecoration(labelText: label),
      items: [
        for (final item in items)
          DropdownMenuItem(value: item, child: Text(labelOf(item))),
      ],
      onChanged: onChanged,
      validator: (selected) => selected == null ? errorText : null,
    );
  }
}
